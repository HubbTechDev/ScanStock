# Inventory Management App

A professional inventory management app for tracking items, storage locations, and sales history.

## Features

### Home Dashboard
- Quick stats overview (In Inventory, To Ship, Shipped counts)
- Ready-to-ship items queue with urgency indicators
- Quick action buttons for scanning items and searching

### Inventory Management
- Add items with photos (camera or gallery)
- Store item details: name, description, custom location fields, platform
- Customizable storage location fields (bin, rack, shelf, etc.)
- Active and Sold tabs within Inventory
- Search by name, bin, rack, or platform
- Sort items by newest or oldest first
- Find items by photo (camera or photo library)
- Edit items after creation

### Storage Settings
- Customize location field names (e.g., Bin, Rack, Shelf, Room)
- Add or remove location fields
- Enable/disable fields without deleting
- Set placeholder text for each field

### Platform Settings
- Pre-configured selling platforms (eBay, Amazon, Etsy, Poshmark, Mercari, Facebook, Depop, OfferUp)
- Add custom platforms with custom names
- Choose from 9 icon options per platform
- Pick from 12 color options per platform
- Enable/disable platforms without deleting
- Visual platform selector when adding/editing items
- Select multiple platforms per item (cross-listed items)

### Ready to Ship (To Ship Tab)
- Scan items to mark them as sold/ready to ship
- Set ship by date with date picker
- Add shipping reminder with push notifications
- Capture shipper's QR code from camera or gallery
- View QR code indicator on items

### Item Details
- Full item information display
- Edit mode for updating item details
- Status actions (Mark Ready to Ship, Mark as Shipped)
- Shipper QR code quick look display
- Set shipping reminders

### Shipped Tab
- View all completed/shipped items
- Search through shipped items
- Access item details and history

## Tech Stack

### Frontend
- Expo SDK 53 with React Native
- Expo Router for navigation
- NativeWind (TailwindCSS) for styling
- React Query for server state
- Lucide icons
- expo-notifications for push notifications
- expo-camera for QR code capture

### Backend
- Bun runtime with Hono server
- Prisma ORM with SQLite
- Better Auth for authentication
- Image upload support

## Database Schema

### InventoryItem
- `id` - Unique identifier
- `name` - Item name
- `description` - Optional description
- `imageUrl` - Photo URL
- `binNumber` - Storage bin location
- `rackNumber` - Storage rack location
- `platform` - Selling platform (eBay, Amazon, etc.)
- `status` - pending | sold | completed
- `soldAt` - Sale timestamp
- `soldPrice` - Sale price
- `shipByDate` - Ship by deadline
- `shipperQrCode` - URL to shipper's QR code image
- `createdAt` - Creation timestamp
- `updatedAt` - Last update timestamp

## API Endpoints

- `GET /api/inventory` - Get all items with stats
- `GET /api/inventory/:id` - Get single item
- `POST /api/inventory` - Create new item
- `PATCH /api/inventory/:id` - Update item
- `DELETE /api/inventory/:id` - Delete item
- `POST /api/inventory/search` - Search items
- `POST /api/inventory/search-by-photo` - Search items by photo
- `POST /api/upload/image` - Upload image

## Color Scheme

- Primary: Charcoal Grey (#1C1C1E)
- Accent: Cyan (#06B6D4)
- Pending/In Inventory: Amber (#F59E0B)
- Ready to Ship: Violet (#8B5CF6)
- Shipped/Completed: Emerald (#10B981)
